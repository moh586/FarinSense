package farin.code.db;

import java.util.ArrayList;
import java.util.List;

import farin.code.db.Setting;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.widget.Toast;

public class DbAdapter {

	public DataBaseHelper mDb;

	/**
	 * Database creation SQL statement
	 */

	private final Context mCtx;


	public DbAdapter(Context ctx){
		this.mCtx=ctx;
		mDb =new DataBaseHelper(ctx);
		try {  
			mDb.createDataBase();
		} catch (Exception ioe) {
			Toast.makeText(ctx, ioe.getMessage(), Toast.LENGTH_SHORT).show();
		}
	}

	//********************************TOPIC******************************
	
	/**
	 * this method is for get topic with an spetial id
	 * @param id identiti of  topic's subject
	 * @return
	 */
	public String SelectTopic(int id) {
		openDB();
		Cursor cursor = mDb.myDataBase.query(Topic.TableName, new String[] {Topic.ID, Topic.SUBJECT}
		, Topic.ID + "=?",
		new String[] { String.valueOf(id) }, null, null, null, null);
		if (cursor != null)
			cursor.moveToFirst();

		String data=cursor.getString(1);

		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		closeDB();
		return data;
	}


	/**
	 * select all topic subject
	 * @return an array that contains Database Subject
	 */
	public String[] SelectAllTopic()
	{
		String[] output;
		int i=0;
		openDB();
		String selectQuery = "SELECT  * FROM " + Topic.TableName;
		Cursor cursor = mDb.myDataBase.rawQuery(selectQuery, null);
		output=new String[cursor.getCount()];
		if (cursor.moveToFirst()) {
			do {
				output[i++]=cursor.getString(1);
			} while (cursor.moveToNext());
		}   
		return output;
	}

	
	//************************************SUBTITLE******************************

	/**
	 * select a subtitle with given id
	 * @param id identity of row we want to selcted
	 * @return selected row
	 */
	public Subtitle SelectSubtitle(int id) {
		openDB();
		Cursor cursor = mDb.myDataBase.query(Subtitle.TableName, new String[] {Subtitle.ID, Subtitle.QUESTION,Subtitle.ANSWER,Subtitle.TOPIC_ID}
		, Subtitle.ID + "=?",
		new String[] { String.valueOf(id) }, null, null, null, null);
		if (cursor != null)
			cursor.moveToFirst();

		Subtitle item=new Subtitle(cursor.getInt(0), cursor.getString(1), 
				cursor.getString(2), cursor.getInt(3));

		closeDB();
		return item;
	}

	/**
	 * select all rows that have given topic_id
	 * @param topic_id identeity of topic_id of selected rows
	 * @return selected rows
	 */
	public List<Subtitle> SelectSubtitleList(int topic_id) {
		List<Subtitle> rulesList = new ArrayList<Subtitle>();
		openDB();
		Cursor cursor = mDb.myDataBase.query(Subtitle.TableName, new String[] {Subtitle.ID, Subtitle.QUESTION,Subtitle.ANSWER,Subtitle.TOPIC_ID}
		, Subtitle.TOPIC_ID + "=?",
		new String[] { String.valueOf(topic_id) }, null, null, null, null);
		if (cursor.moveToFirst()) {
			do {
				Subtitle item=new Subtitle(cursor.getInt(0), cursor.getString(1), 
						cursor.getString(2), cursor.getInt(3));
				// Adding contact to list
				rulesList.add(item);
			} while (cursor.moveToNext());
		}
		closeDB();
		return rulesList;
	}


	/**
	 * for excute a query for search 
	 * @param query search query
	 * @return result of search query
	 */
	public List<Subtitle> selectRecordsFromDB(String query){ 
		openDB();
		List<Subtitle> list = new ArrayList<Subtitle>();
		Cursor cursor = mDb.myDataBase.rawQuery(query, null);            
		if (cursor.moveToFirst()) {
			do {                 
				list.add(new Subtitle(cursor.getInt(0), cursor.getString(1), 
						cursor.getString(2), cursor.getInt(3)));

			} while (cursor.moveToNext());
		}
		closeDB();
		return list;
	}

	//************************Setting************************
	/**
	 * for get setting parametr value id you shoud use it like this
	 * Select(Setting.RESHAPE) that return value of reshape variable
	 * @param id row of table setting id is one of 4 satatic field in setting
	 * @return value of row
	 */
	public int Select(int id) {
    	openDB();
        Cursor cursor = mDb.myDataBase.query(Setting.TableName, new String[] {Setting.ID, Setting.VALULE}
        , Setting.ID + "=?",
        new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
        
        int data=cursor.getInt(1);
        closeDB();
        return data;
    }
   
	/**
	 * for set value of setting youshould set like this example
	 * Update(Setting.SOUND,1) it's mean is set value of sound row
	 * in table setting be 1
	 * @param id id of row we want update
	 * @param value value we want to set to parametr
	 */
    public void Update(int id,int value)
    {
    	openDB();
    	ContentValues cv = new ContentValues();
    	cv.put(Setting.VALULE,value>0?1:0); //These Fields should be 0 or 1
    	mDb.myDataBase.update(Setting.TableName, cv, Setting.ID+"="+id, null);
    	closeDB();
    }
	
	
	//*************************************Database Method**************************
	
	/**
	 * for opening database
	 */
	public void openDB()
	{
		try {        
			mDb.openDataBase();
		}catch(Exception sqle){
			Toast.makeText(mCtx, sqle.getMessage(), Toast.LENGTH_SHORT).show();
		}
	}

	/**
	 * for closing database
	 */
	public void closeDB()
	{
		mDb.close();
	}
}
