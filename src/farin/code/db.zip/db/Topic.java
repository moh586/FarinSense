package farin.code.db;

public class Topic {
	public static String TableName="Topic";
	public static String ID="_id";
	public static String SUBJECT="subject";
	
	private int id;
	private String subject;
	
	
	
	
	public Topic(int id, String subject) {
		super();
		this.id = id;
		this.subject = subject;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	

}
