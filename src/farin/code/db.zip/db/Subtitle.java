package farin.code.db;

public class Subtitle {
	public static String TableName="Topic";
	public static String ID="_id";
	public static String QUESTION="question";
	public static String ANSWER="answer";
	public static String TOPIC_ID="topic_id";
	
	private int id,topic_id;
	private String question;
	private String answer;
	
	
	
	
	
	
	public Subtitle(int id, String question, String answer,int topic_id) {
		super();
		this.id = id;
		this.question = question;
		this.answer = answer;
		this.topic_id=topic_id;
	}
	
	
	
	
	
	public int getTopic_id() {
		return topic_id;
	}
	public void setTopic_id(int topic_id) {
		this.topic_id = topic_id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	
}
