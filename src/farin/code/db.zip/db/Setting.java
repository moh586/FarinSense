package farin.code.db;

public class Setting {
	public static String TableName="Setting";
	public static String ID="_id";
	public static String VALULE="value";
	public static String NAME="name";
	
	public static int FIRST=1;
	public static int RESHAPE=2;
	public static int SOUND=3;
	public static int TEXTSIZE=4;
	
	
	private int id,value;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public Setting(int id, int value) {
		super();
		this.id = id;
		this.value = value;
	}
	
	
}
